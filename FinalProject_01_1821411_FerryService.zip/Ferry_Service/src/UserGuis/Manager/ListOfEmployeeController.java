package UserGuis.Manager;

import Classes.Manager;
import Classes.Employee;
import Classes.FerryHeadOffice;
import Classes.User;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class ListOfEmployeeController implements Initializable {

    @FXML
    private TableView<ListOfAccount> Table;
    @FXML
    private TableColumn<ListOfAccount, String> name;
    @FXML
    private TableColumn<ListOfAccount, String> id;
    @FXML
    private TableColumn<ListOfAccount, String> dob;
    @FXML
    private TableColumn<ListOfAccount, String> address;
    @FXML
    private TableColumn<ListOfAccount, String> gender;
    @FXML
    private TableColumn<ListOfAccount, String> email;

    private Manager selectedManeger;

    public void passData(Manager m) {
        selectedManeger = m;

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        listOfaccount();
        name.setCellValueFactory(new PropertyValueFactory<ListOfAccount, String>("name"));
        id.setCellValueFactory(new PropertyValueFactory<ListOfAccount, String>("id"));
        dob.setCellValueFactory(new PropertyValueFactory<ListOfAccount, String>("dob"));
        address.setCellValueFactory(new PropertyValueFactory<ListOfAccount, String>("address"));
        gender.setCellValueFactory(new PropertyValueFactory<ListOfAccount, String>("gender"));
        email.setCellValueFactory(new PropertyValueFactory<ListOfAccount, String>("email"));
    }

    @FXML
    private void backButtonOnClick(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("ManagerMainPanel.fxml"));
        Parent personViewParent = loader.load();
        Scene personViewScene = new Scene(personViewParent);
        ManagerMainPanelController controller2 = loader.getController();
        controller2.passData((User) selectedManeger);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(personViewScene);
        window.show();
    }

    @FXML
    private void EmployeeButtonOnClick(ActionEvent event) {
        System.out.println("Done...1");
        Table.setItems(totalEmployee);
    }

    @FXML
    private void ManagerButtonOnClick(ActionEvent event) {
        System.out.println("Done ...2");
        Table.setItems(totalManager);
    }

    @FXML
    private void FerryHeadOfficeButtonOnClick(ActionEvent event) {
        System.out.println("Done ...3");
        Table.setItems(totalFerryHeadOffice);
    }

    ObservableList<ListOfAccount> totalEmployee = FXCollections.observableArrayList();
    ObservableList<ListOfAccount> totalManager = FXCollections.observableArrayList();
    ObservableList<ListOfAccount> totalFerryHeadOffice = FXCollections.observableArrayList();

    public ObservableList<ListOfAccount> EmployeeInfo() {
        return totalEmployee;
    }

    void listOfaccount() {
        File f = null;
        FileInputStream fis = null;
        ObjectInputStream ois = null;
        try {
            f = new File("user.bin");
            fis = new FileInputStream(f);
            ois = new ObjectInputStream(fis);
            User u;
            try {
                while (true) {
                    u = (User) ois.readObject();
                    if (!u.getIsSuspend() && !u.getDeleteAccount()) {
                        ListOfAccount l = new ListOfAccount(u.getName(), u.getId(), u.getDob(), u.getGender(), u.getEmail(), u.getAddress());
                        if (u instanceof Employee) {
                            totalEmployee.add(l);
                        } else if (u instanceof Manager) {
                            totalManager.add(l);
                        } else if (u instanceof FerryHeadOffice) {
                            totalFerryHeadOffice.add(l);
                        }
                    }
                }
            } catch (Exception e) {
            }
        } catch (IOException ex) {
        } finally {
            try {
                if (ois != null) {
                    ois.close();
                }
            } catch (IOException ex) {
            }
        }
    }
}
