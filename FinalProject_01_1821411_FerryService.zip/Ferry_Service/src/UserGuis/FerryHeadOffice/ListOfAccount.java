/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserGuis.FerryHeadOffice;

/**
 *
 * @author Acer
 */
public class ListOfAccount {
     String name;
     String id;
     String dob;
     String gender;
     String email;
     String address;

    public ListOfAccount(String name, String id, String dob, String gender, String email, String address) {
        this.name = name;
        this.id = id;
        this.dob = dob;
        this.gender = gender;
        this.email = email;
        this.address = address;
    }

    public ListOfAccount(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public String getDob() {
        return dob;
    }

    public String getGender() {
        return gender;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }
     
     
}
