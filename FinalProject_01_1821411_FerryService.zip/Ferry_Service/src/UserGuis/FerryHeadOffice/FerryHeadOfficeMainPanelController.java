package UserGuis.FerryHeadOffice;

import Classes.FerryHeadOffice;
import Classes.User;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Hp-laptop
 */
public class FerryHeadOfficeMainPanelController implements Initializable {

    /**
     * Initializes the controller class.
     */
   
    @FXML
    private Label label;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }   
     private FerryHeadOffice selectedFerryHeadOffice;
    public void passData(User m){
        selectedFerryHeadOffice = (FerryHeadOffice)m;
            
    }
    
       public void passinfo(User m){
       selectedFerryHeadOffice = (FerryHeadOffice)m;         
    }
    
    
 
    @FXML
    private void logoutButtonOnClick(ActionEvent event) throws IOException {
        ButtonType yes = new ButtonType("Yes");
        ButtonType no = new ButtonType("No");
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText(null);
        alert.setContentText("Do you want to Sign Out?");
        alert.getButtonTypes().clear();
        alert.getButtonTypes().addAll(yes, no);
        Optional<ButtonType> option = alert.showAndWait();
        
        if (option.get() == null) {
            System.out.println("ERROR 404!");
        } else if (option.get() == yes) {
        Parent root = FXMLLoader.load(getClass().getResource("/ferry_service/LogIn.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(scene);
        window.show();
        }
    }

    @FXML
    private void ApproveJobListbuttonOnClick(ActionEvent event) {
        try{
       
        FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("ApproveJobList.fxml"));
            Parent personViewParent = loader.load();
            Scene personViewScene = new Scene(personViewParent);
            ApproveJobListController controller2 = loader.getController();
            controller2.passData(selectedFerryHeadOffice);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(personViewScene);
            window.show();
        }
        catch(Exception e)
        {
            ButtonType b = new ButtonType("Ok");
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("No JobList found");
            alert.getButtonTypes().clear();
            alert.getButtonTypes().addAll(b);
            Optional<ButtonType> option = alert.showAndWait();
            if(option.get().equals(null))
            {
                System.out.println("Print 404...!!!");
            }
        }
    }
    @FXML
    private void ApprovePromotionListButtonOnClick(ActionEvent event) throws IOException {
        
        FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("ApprovePromotionList.fxml"));
            Parent personViewParent = loader.load();
            Scene personViewScene = new Scene(personViewParent);
            ApprovePromotionListController controller2 = loader.getController();
            controller2.passData(selectedFerryHeadOffice);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(personViewScene);
            window.show();
    }

    @FXML
    private void AssignMaxMinFareButtonOnClick(ActionEvent event) throws IOException {
        
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("AssignMaxMinFare.fxml"));
        Parent personViewParent = loader.load();
        Scene personViewScene = new Scene(personViewParent);
        AssignMaxMinFareController controller2 = loader.getController();
        controller2.passData(selectedFerryHeadOffice);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(personViewScene);
        window.show();
    }

    @FXML
    private void InnovativeActivitiesButtonOnClick(ActionEvent event) throws IOException {
      
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("InnovativeActivities.fxml"));
        Parent customer = loader.load();
        Scene customerScene = new Scene(customer);
        InnovativeActivitiesController controller = loader.getController();
        controller.passData((User)selectedFerryHeadOffice);
        Stage customerWindow = (Stage) ((Node) event.getSource()).getScene().getWindow();
        customerWindow.setScene(customerScene);
        customerWindow.show();
    }

   
    @FXML
    private void ChangeMeetScheduleButtonOnClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("ChangeMeetSchedule.fxml"));
        Parent customer = loader.load();
        Scene customerScene = new Scene(customer);
        ChangeMeetScheduleController controller = loader.getController();
        controller.passData((User)selectedFerryHeadOffice);
        Stage customerWindow = (Stage) ((Node) event.getSource()).getScene().getWindow();
        customerWindow.setScene(customerScene);
        customerWindow.show();
        
    }


}
