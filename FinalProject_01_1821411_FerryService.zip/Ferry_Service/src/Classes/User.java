
package Classes;

import java.io.Serializable;
import static jdk.nashorn.internal.runtime.Debug.id;

public abstract class User implements Serializable{
    protected String name;
    protected String id;
    protected String dob;
    protected String gender;
    protected String email;
    protected String address;
    protected String password;
    protected Boolean isSuspend;
    protected String suspendReason;
    protected Boolean deleteAccount;

    public String getSuspendReason() {
        return suspendReason;
    }

    public void setSuspendReason(String suspendReason) {
        this.suspendReason = suspendReason;
    }
    
    public String getGender() {
        return gender;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public String getPassword() {
        return password;
    }

    public Boolean getIsSuspend() {
        return isSuspend;
    }
    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public String getDob() {
        return dob;
    }
    public abstract void showInformation(String name,String id,String dob,String gender, String email,String address);
    public void showInfo()
    {
        System.out.println("Name: "+name+" ID: "+id+ " Date Of Birth: " + dob + " Gender: " + gender + " Email " + email + " Address: "+ address );
    }

    public void setIsSuspend(Boolean isSuspend) {
        this.isSuspend = isSuspend;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Boolean getDeleteAccount() {
        return deleteAccount;
    }

    public void setDeleteAccount(Boolean deleteAccount) {
        this.deleteAccount = deleteAccount;
    }

    public User() {
    }
    
    
}
