/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import UserGuis.Admin.CreateNewAccountController;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;

/**
 *
 * @author HP
 */
public class Admin extends User implements Serializable{
    
    @Override
    public void showInformation(String name, String id, String dob, String gender, String email, String address) 
    {
        System.out.println("Name: "+name+"ID: "+id+ "Date Of Birth: " + dob + "Gender: " + gender + "Email " + email + "Address: "+ address );
    }
    public void addinformation(String type, String gender, String email, String add, String name, String dob)
    {
        
    }

    public Admin(String name, String id, String dob, String gender, String email, String address) {
        this.name = name;
        this.id = id;
        this.dob = dob;
        this.gender = gender;
        this.email = email;
        this.address = address;
        this.password = id;
        this.isSuspend = false;
    }
    public static void createNewAccount(String name, String type,  String id, String dob, String gender, String email, String address){
        User u = null;
        if (type == "Manager") {
            u = new Manager(name, id, dob, gender, email, address) ;
        } else if (type == "FerryHeadOffice") {
            u = new FerryHeadOffice(name, id, dob, gender, email, address) ;
        } else if (type == "Employee") {
            u = new Employee(name, id, dob, gender, email, address) ;
        }
              
        File f = null;
        FileOutputStream fos = null;      
        ObjectOutputStream oos = null;        
        try {
            f = new File("user.bin");
            if(f.exists()){
                fos = new FileOutputStream(f,true);
                oos = new AppendableObjectOutputStream(fos);                  
            }
            else{
                fos = new FileOutputStream(f);
                oos = new ObjectOutputStream(fos);               
            }
            oos.writeObject(u);

        } catch (IOException ex) {  } finally {
            try {
                if(oos != null) {
                    oos.flush();
                    oos.close();
                }
            } catch (IOException ex) { }
        }     
        
    }
    
      
       
}
