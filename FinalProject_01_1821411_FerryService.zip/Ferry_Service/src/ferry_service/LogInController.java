package ferry_service;

import Classes.Manager;
import Classes.FerryHeadOffice;
import Classes.Employee;
import Classes.User;
import UserGuis.Manager.ManagerMainPanelController;
import UserGuis.FerryHeadOffice.FerryHeadOfficeMainPanelController;
import UserGuis.Employee.EmployeeMainPanelController;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LogInController implements Initializable {

    @FXML
    private TextField id;
    @FXML
    private PasswordField password;
    @FXML
    private Label label;

    @FXML
    private void backOnClick(ActionEvent event) throws IOException {
        Parent scene2Parent = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        Scene scene2 = new Scene(scene2Parent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(scene2);
        window.show();
    }

    @FXML
    private void logInUserOnClick(ActionEvent event) throws IOException {
        String s = id.getText();
        User u = idValidation();
         if (id.getText().toString().equals("1234")) // admin
        {
            if (password.getText().equals("1234")) {
                Parent scene2Parent = FXMLLoader.load(getClass().getResource("/UserGuis/Admin/AdminMainPanel.fxml"));
                Scene scene2 = new Scene(scene2Parent);
                Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                window.setScene(scene2);
                window.show();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setContentText("Invalid Username or Password!");
                alert.showAndWait();
            }
        }
         else if (u == null) {
            label.setText("Invalid Account. Please Contact with Admin");
            id.setText("");
            password.setText("");
        }
         else if (s.charAt(0) == '2') {
            if (u != null) {

                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/UserGuis/Manager/ManagerMainPanel.fxml"));
                Parent personViewParent = loader.load();
                Scene personViewScene = new Scene(personViewParent);
                ManagerMainPanelController controller = loader.getController();
                controller.passData((User) idValidation());
                Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                window.setScene(personViewScene);
                window.show();

            }

        } else if (s.charAt(0) == '3') {
            if (u != null) {
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/UserGuis/FerryHeadOffice/FerryHeadOfficeMainPanel.fxml"));
                Parent personViewParent = loader.load();
                Scene personViewScene = new Scene(personViewParent);
                FerryHeadOfficeMainPanelController controller2 = loader.getController();
                controller2.passData(u);
                Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                window.setScene(personViewScene);
                window.show();
            }
        } else if (s.charAt(0) == '4') {
            
             System.out.println("I am hereee...");
             FXMLLoader loader = new FXMLLoader();
             loader.setLocation(getClass().getResource("/UserGuis/Employee/EmployeeMainPanel.fxml"));
             Parent personViewParent = loader.load();
              Scene personViewScene = new Scene(personViewParent);
              EmployeeMainPanelController controller2 = loader.getController();
               controller2.passData(u);
               Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                window.setScene(personViewScene);
                window.show();

            }
     
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void forgetPassButtonOnClick(ActionEvent event) throws IOException {
        Parent scene2Parent = FXMLLoader.load(getClass().getResource("Forget_Passwrod.fxml"));
        Scene scene2 = new Scene(scene2Parent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(scene2);
        window.show();
    }

    User idValidation() {
        User u = null;
        String ID = id.getText().toString();
        String pass = password.getText().toString();
        //System.out.println(ID + "      " + pass);
        File f = null;
        FileInputStream fis = null;
        ObjectInputStream ois = null;

        f = new File("user.bin");
        if (f.exists()) {
            try {
                fis = new FileInputStream(f);
                ois = new ObjectInputStream(fis);

                try {
                    while (true) {

                        u = (User) ois.readObject();
                        /*
                        if(u instanceof Manager)
                        {
                            u = (Manager)u;
                        }
                        else if(u instanceof Employee )
                        {
                            u = (Employee)u;
                        }
                        else if(u instanceof FerryHeadOffice )
                        {
                            u = (FerryHeadOffice)u;
                        }*/
                        String userID = u.getId();
                        String pass1 = u.getPassword();
                        //System.out.println(userID + "    " + pass1 + "  " + u.getName());
                        if (userID.equals(ID) && userID.equals(pass) && !u.getIsSuspend() && !u.getDeleteAccount()) {
                            break;

                        }
                    }

                } catch (Exception e) {
                    u = null;
                }
            } catch (IOException ex) {
            } finally {
                try {
                    if (ois != null) {
                        ois.close();
                    }
                } catch (IOException ex) {
                }
            }

        }
        return u;
    }
}
