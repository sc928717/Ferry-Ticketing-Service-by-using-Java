package ferry_service;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
public class ProgrameController implements Initializable {

    @FXML
    private Label RoutesSchedulesLabel;
    @FXML
    private Label TicketInfoLabel;
    @FXML
    private Label APPguideLabel;
    @FXML
    private Label ExperienceLabel;

    @FXML
    private void backButtonOnClick(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void RoutesSchedulesButtonOnClick(Event event) {
           String str = "";
        File f = null;
        Scanner sc; String s; String[] tokens;
        try {
            f = new File("newAddedProgramInfo.txt");
            sc = new Scanner(f);
            if(f.exists()){
               
                while(sc.hasNextLine()){
                    s=sc.nextLine();
          
                    {
                        str += s + " \n";
                       
                    }
                }
            }
           
                
        } 
        catch (IOException ex) {} 
        finally {
            RoutesSchedulesLabel.setText(str);
        }        
    }
    

    

    @FXML
    private void TicketInfoButtonOnClick(Event event) {
           String str = "";
        File f = null;
        Scanner sc; String s; String[] tokens;
        try {
            f = new File("newAddedProgramInfo2.txt");
            sc = new Scanner(f);
            if(f.exists()){
               
                while(sc.hasNextLine()){
                    s=sc.nextLine();

                    {
                        str += s + " \n";
                       
                    }
                }
            }
           
                
        } 
        catch (IOException ex) {} 
        finally {
            TicketInfoLabel.setText(str);
        }        
    }

    @FXML
    private void APPguideButtonOnClick(Event event) {
         String str = "";
        File f = null;
        Scanner sc; String s; String[] tokens;
        try {
            f = new File("newAddedProgramInfo3.txt");
            sc = new Scanner(f);
            if(f.exists()){
               
                while(sc.hasNextLine()){
                    s=sc.nextLine();

                    {
                        str += s + "\n";
                    }
                }
            }
           
                
        } 
        catch (IOException ex) {} 
        finally {
            APPguideLabel.setText(str);
        }        

    }

    @FXML
    private void ExperienceButtonOnClick(Event event) {
             String str = "";
        File f = null;
        Scanner sc; String s; String[] tokens;
        try {
            f = new File("newAddedProgramInfo4.txt");
            sc = new Scanner(f);
            if(f.exists()){
               
                while(sc.hasNextLine()){
                    s=sc.nextLine();
                    {
                        str += s + "\n";
                    }
                }
            }
           
                
        } 
        catch (IOException ex) {} 
        finally {
            ExperienceLabel.setText(str);
        }
    }
    
}
