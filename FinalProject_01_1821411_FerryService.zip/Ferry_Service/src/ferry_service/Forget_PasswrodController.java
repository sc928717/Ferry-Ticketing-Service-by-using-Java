package ferry_service;

import Classes.User;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Forget_PasswrodController implements Initializable {

    @FXML    private TextField id ;
    @FXML    private Label password;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void forgetPasswrodButtonOnClick(ActionEvent event) {
        if(!id.getText().toString().equals(null))
        {
            password.setText("Password Changing request has been send. \n  Please Contact with Admin");
            User u = idValidation();
            File f = null;
        FileOutputStream fos = null;      
        ObjectOutputStream oos = null;        
        try {
            f = new File("forgetPasswrodList.bin");
            if(f.exists()){
                fos = new FileOutputStream(f,true);
                oos = new AppendableObjectOutputStream(fos);                
            }
            else{
                fos = new FileOutputStream(f);
                oos = new ObjectOutputStream(fos);               
            }
            oos.writeObject(u);

        } catch (IOException ex) {  } finally {
            try {
                if(oos != null) {
                    oos.flush();
                    oos.close();
                }
            } catch (IOException ex) { }
        }     
        }
        else 
        {
            password.setText("Please write your ID.");
        }
        id.setText("");
    }

    @FXML
    private void backButtonOnClick(ActionEvent event) throws IOException {
        Parent scene2Parent = FXMLLoader.load(getClass().getResource("LogIn.fxml"));
        Scene scene2 = new Scene(scene2Parent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(scene2);
        window.show();
    }
    User idValidation() {
        User u = null;
        String ID = id.getText().toString();
        File f = null;
        FileInputStream fis = null;
        ObjectInputStream ois = null;

        f = new File("user.bin");
        if (f.exists()) {
            try {
                fis = new FileInputStream(f);
                ois = new ObjectInputStream(fis);

                try {
                    while (true) {

                        u = (User) ois.readObject();
                        String userID = u.getId();
                       
                        if (userID.equals(ID) && !u.getIsSuspend() && !u.getDeleteAccount()) {
                            break;

                        }
                    }

                } catch (Exception e) {
                    u = null;
                }
            } catch (IOException ex) {
            } finally {
                try {
                    if (ois != null) {
                        ois.close();
                    }
                } catch (IOException ex) {
                }
            }

        }
        return u;
    }
    class AppendableObjectOutputStream extends ObjectOutputStream {
        public AppendableObjectOutputStream(OutputStream out) throws IOException 
        {
            super(out);
        }
        @Override
        protected void writeStreamHeader() throws IOException {
        }
    }
}
